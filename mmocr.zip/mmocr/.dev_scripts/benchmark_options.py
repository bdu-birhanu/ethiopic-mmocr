# Copyright (c) OpenMMLab. All rights reserved.

third_part_libs = [
    'pip install -r ../requirements/albu.txt',
]

default_floating_range = 0.5
