# Copyright (c) OpenMMLab. All rights reserved.
from .sdmgr_postprocessor import SDMGRPostProcessor

__all__ = ['SDMGRPostProcessor']
