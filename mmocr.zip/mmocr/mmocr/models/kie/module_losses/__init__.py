# Copyright (c) OpenMMLab. All rights reserved.
from .sdmgr_module_loss import SDMGRModuleLoss

__all__ = ['SDMGRModuleLoss']
