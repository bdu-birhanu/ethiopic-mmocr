# Copyright (c) OpenMMLab. All rights reserved.

from .dictionary import Dictionary

__all__ = ['Dictionary']
