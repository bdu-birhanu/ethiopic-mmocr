# Copyright (c) OpenMMLab. All rights reserved.
from .common import AvgPool2d

__all__ = ['AvgPool2d']
