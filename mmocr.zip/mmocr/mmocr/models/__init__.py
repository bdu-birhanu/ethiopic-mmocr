# Copyright (c) OpenMMLab. All rights reserved.
from .common import *  # NOQA
from .kie import *  # NOQA
from .textdet import *  # NOQA
from .textrecog import *  # NOQA
