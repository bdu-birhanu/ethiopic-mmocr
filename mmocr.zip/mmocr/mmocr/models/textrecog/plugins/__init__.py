# Copyright (c) OpenMMLab. All rights reserved.
from .common import GCAModule, Maxpool2d

__all__ = ['Maxpool2d', 'GCAModule']
