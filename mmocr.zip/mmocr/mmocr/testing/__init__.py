# Copyright (c) OpenMMLab. All rights reserved.
from .data import create_dummy_dict_file, create_dummy_textdet_inputs

__all__ = ['create_dummy_dict_file', 'create_dummy_textdet_inputs']
