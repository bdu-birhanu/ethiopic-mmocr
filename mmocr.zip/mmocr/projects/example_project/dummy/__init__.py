from .dummy_resnet import DummyResNet

__all__ = ['DummyResNet']
