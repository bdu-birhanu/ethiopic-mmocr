# Copyright (c) OpenMMLab. All rights reserved.
from .bezier_utils import bezier2poly, poly2bezier

__all__ = ['poly2bezier', 'bezier2poly']
