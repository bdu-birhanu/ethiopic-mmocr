# Copyright (c) OpenMMLab. All rights reserved.
from .e2e_point_metric import E2EPointMetric

__all__ = ['E2EPointMetric']
