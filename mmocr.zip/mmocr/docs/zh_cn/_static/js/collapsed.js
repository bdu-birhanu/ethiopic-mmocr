var collapsedSections = ['MMOCR 0.x 迁移指南', 'API 文档']
