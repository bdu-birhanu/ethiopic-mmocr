var collapsedSections = ['Migration Guides', 'API Reference']
