.. role:: hidden
    :class: hidden-section

mmocr.engine
===================================

.. contents:: mmocr.engine
   :depth: 2
   :local:
   :backlinks: top

.. currentmodule:: mmocr.engine.hooks

Hooks
---------------------------------------------

.. autosummary::
   :toctree: generated
   :nosignatures:
   :template: classtemplate.rst

   VisualizationHook
