.. role:: hidden
    :class: hidden-section

mmocr.structures
===================================

.. currentmodule:: mmocr.structures
.. autosummary::
   :toctree: generated
   :nosignatures:
   :template: classtemplate.rst

   TextDetDataSample
   TextRecogDataSample
   KIEDataSample
