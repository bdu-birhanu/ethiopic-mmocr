.. role:: hidden
    :class: hidden-section

mmocr.visualization
===================================

.. currentmodule:: mmocr.visualization

.. autosummary::
   :toctree: generated
   :nosignatures:
   :template: classtemplate.rst

   BaseLocalVisualizer
   TextDetLocalVisualizer
   TextRecogLocalVisualizer
   TextSpottingLocalVisualizer
   KIELocalVisualizer
