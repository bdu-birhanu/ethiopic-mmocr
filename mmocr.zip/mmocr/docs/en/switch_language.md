## <a href='https://mmocr.readthedocs.io/en/dev-1.x/'>English</a>

## <a href='https://mmocr.readthedocs.io/zh_CN/dev-1.x/'>简体中文</a>
